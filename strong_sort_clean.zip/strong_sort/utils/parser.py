from yacs.config import CfgNode as CN

def get_config():
    _C = CN()

    _C.MODEL = CN()
    _C.MODEL.REID_CKPT = "osnet_x0_25_msmt17.pt"

    _C.DETECTION = CN()
    _C.DETECTION.MIN_CONFIDENCE = 0.3
    _C.DETECTION.NMS_MAX_OVERLAP = 0.5

    _C.TRACKER = CN()
    _C.TRACKER.MAX_IOU_DISTANCE = 0.7
    _C.TRACKER.MAX_AGE = 70
    _C.TRACKER.N_INIT = 3
    _C.TRACKER.NN_BUDGET = 100

    _C.DISTANCE_METRIC = CN()
    _C.DISTANCE_METRIC.MAX_DIST = 0.2

    return _C